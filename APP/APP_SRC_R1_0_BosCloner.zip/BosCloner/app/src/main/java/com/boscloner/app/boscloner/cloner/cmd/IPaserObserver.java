package com.boscloner.app.boscloner.cloner.cmd;

/**
 * Created by jpiat on 10/19/15.
 */
public interface IPaserObserver {

    public abstract void commandParsed(ClonerCommand cmd);
}
