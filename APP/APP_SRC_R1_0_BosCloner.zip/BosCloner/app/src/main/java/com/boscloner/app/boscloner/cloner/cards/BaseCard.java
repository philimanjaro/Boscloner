package com.boscloner.app.boscloner.cloner.cards;

/**
 * Created by jpiat on 12/17/15.
 */
public class BaseCard extends AbstractCard {
}
