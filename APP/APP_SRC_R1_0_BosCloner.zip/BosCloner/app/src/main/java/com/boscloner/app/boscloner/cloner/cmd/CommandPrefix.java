package com.boscloner.app.boscloner.cloner.cmd;

/**
 * Created by jpiat on 10/16/15.
 */
public class CommandPrefix {
    public static final String VALUE = "$!";
}
