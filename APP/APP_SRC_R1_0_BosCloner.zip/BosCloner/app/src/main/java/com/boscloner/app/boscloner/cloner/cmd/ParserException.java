package com.boscloner.app.boscloner.cloner.cmd;

/**
 * Created by jpiat on 10/19/15.
 */
public class ParserException extends Exception {
}
