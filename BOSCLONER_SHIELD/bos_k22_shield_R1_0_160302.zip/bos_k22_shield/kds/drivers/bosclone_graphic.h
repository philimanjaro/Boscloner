/*
 * bosclone_graphic.h
 *
 *  Created on: Dec 16, 2015
 *      Author: MJ
 */

#ifndef SOURCES_BOSCLONE_GRAPHIC_H_
#define SOURCES_BOSCLONE_GRAPHIC_H_



extern const unsigned char  boscloner_logo_128_64 [];
extern const unsigned char boscloner_logo_90_64 [];


#endif /* SOURCES_BOSCLONE_GRAPHIC_H_ */
