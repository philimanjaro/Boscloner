#include "proxmark3.h"
/* Generated file, do not edit */
const struct version_information __attribute__((section(".version_information"))) version_information = {
	VERSION_INFORMATION_MAGIC,
	1,
	1,
	0,
	"svn 852",
	"2016-02-16 02:48:22",
};
