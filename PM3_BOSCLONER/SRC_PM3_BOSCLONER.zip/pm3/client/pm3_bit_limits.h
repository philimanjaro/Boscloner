#define BITLIB_FLOAT_BITS 53
#define BITLIB_FLOAT_MAX  0xfffffffffffffL
#define BITLIB_FLOAT_MIN  (-0x10000000000000L)
#define BITLIB_FLOAT_UMAX 0x1fffffffffffffUL
