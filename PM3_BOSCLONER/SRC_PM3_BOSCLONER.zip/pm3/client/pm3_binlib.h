#ifndef PM3_BINLIB
#define PM3_BINLIB

#include <lua.h>
int set_bin_library (lua_State *L);

#endif /* PM3_BINLIB */
